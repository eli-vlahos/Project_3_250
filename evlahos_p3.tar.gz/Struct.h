/*
 * Struct.h
 *
 *  Created on: Oct. 7, 2020
 *      Author: elicv
 */

#ifndef STRUCT_H_
#define STRUCT_H_

#include <iostream>
#include <vector>

struct Struct {
	int row;
	int column;
	double weight;
};

#endif /* STRUCT_H_ */
